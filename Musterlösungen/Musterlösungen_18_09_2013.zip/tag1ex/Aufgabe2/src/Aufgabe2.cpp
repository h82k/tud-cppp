#include <iostream>
using namespace std;

#include "functions.h"

int main() {
	task_e();
}
