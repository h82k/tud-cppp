/*
 * Building.cpp
 */

#include <iostream>

using std::cout;
using std::endl;

#include "Building.h"

Building::Building(int numberOfFloors) {
	// add given number of floors
	while (numberOfFloors-- > 0)
		floors.push_back(Floor());
}

void Building::letPopleIn() {
	elevator.addPeople(floors.at(elevator.getFloor()).removeAllPeople());
}

std::vector<Person> Building::removeArrivedPeople() {
	return elevator.removeArrivedPeople();
}

void Building::moveElevatorToFloor(int i) {
	elevator.moveToFloor(i);
}

void Building::addWaitingPerson(int floor, Person p) {
	floors.at(floor).addWaitingPerson(p);
}
