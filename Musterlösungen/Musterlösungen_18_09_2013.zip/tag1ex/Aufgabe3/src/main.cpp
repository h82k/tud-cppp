#include <iostream>
#include "PatternPrinter.h"

using namespace std;

int main() {
	PatternPrinter patPrint;
	patPrint.printPattern();
	
	return 0;
}

