/*
 * Expression.cpp
 */

#include "Expression.h"

#include <iostream>

using namespace std;

Expression::Expression() {
	cout << "Creating Expression" << endl;
}

Expression::~Expression() {
	cout << "Deleting Expression" << endl;
}

