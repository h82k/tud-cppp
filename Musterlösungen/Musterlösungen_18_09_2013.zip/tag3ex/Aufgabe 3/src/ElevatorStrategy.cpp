/*
 * ElevatorStrategy.cpp
 */

#include "ElevatorStrategy.h"

ElevatorStrategy::~ElevatorStrategy() {
	
}

void ElevatorStrategy::createPlan(const Building *b) {
	building = b;
}

