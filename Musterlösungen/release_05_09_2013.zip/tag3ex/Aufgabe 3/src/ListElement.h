/*
 * ListElement.h
 */

#ifndef LISTELEMENT_H_
#define LISTELEMENT_H_

class ListElement {
public:
	~ListElement();
};

#endif /* LISTELEMENT_H_ */
