/*
 * ListElement.cpp
 *
 *  Created on: Aug 26, 2013
 *      Author: jgdo
 */

#include "ListElement.h"

ListElement::ListElement() {
	// TODO Auto-generated constructor stub
	
}

ListElement::~ListElement() {
	// TODO Auto-generated destructor stub
}

