/*
 * ElevatorStrategy.cpp
 */

#include "ElevatorStrategy.h"

ElevatorStrategy::~ElevatorStrategy() {
	
}

void ElevatorStrategy::createPlan(Building *b) {
	building = b;
}

