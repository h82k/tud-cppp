/*
 * functions.h
 */

#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_

void print_star(int n);

void task_b();

void task_d();

char next_char();

void print_char(int n);

void task_e();

#endif /* FUNCTIONS_H_ */
